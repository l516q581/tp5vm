<?php
namespace app\test\controller;
use think\Controller;
use think\Request;
use app\test\model\Teacher;
class Loginc extends Controller
{
   //用户登录表单
  public function index()
  {
	return $this->fetch(); 
  }	
	//处理用户登录提交的数据
  
  public function login()
  {
	$datal=Request::instance()->post();
	$Teacher= new Teacher;
	if($Teacher->login($datal['username'],$datal['password']))
	{
	    return $this->success('登录成功',url('Teacher1c/index'));	
	}
	else
	{
		return $this->error('用户名或密码错误',url('index'));
	}
	
	/*$map=array('username'=>$datal['username']);
	$Teacher=Teacher::get($map);
	if(!is_null($Teacher) and $datal['password']===$Teacher->getData('password'))
	{
		session('tid',$Teacher->getData('id'));
		return $this->success('登录成功',url('Teacher1c/index'));		
	}
	else
	{
	    return $this->error('用户名或密码错误',url('index'));
	}*/
  }	


}