<?php
namespace app\test\controller;
use think\Controller;
use app\test\model\Teacher;
use think\Request;
class Teacher1c extends Controller
{
	
    public function index()
    {
		$name=Request::instance()->get('name');
		echo $name;
		$pageSize=5;
		$Teacher=new Teacher;		
		$teachers=$Teacher->paginate($pageSize,false,['query'=>['name'=>$name,]]);
		$_Teacher=$this->assign('teachers',$teachers);
        $htmls=$this->fetch();
		return $htmls;
    }
	
	public function show()
	{
	$Teacherm = new Teacher;
	$teachers=$Teacherm->select();
	dump($teachers);
	}
	
	public function add()
	{
		$htmls=$this->fetch();
		return $htmls;
	}
	
	public function insert()
		{
		try {
		// 接收传入数据
		$postData = Request::instance()->post();
		// 实例化Teacher空对象
		$Teacher = new Teacher();
		// 为对象赋值
		$Teacher->name = $postData['name'];
		$Teacher->username = $postData['username'];
		$Teacher->sex = $postData['sex'];
		$Teacher->email = $postData['email'];
		// 新增对象至数据表
		$result = $Teacher->validate(true)->save();
		// 反馈结果
		if (false === $result)
		{
		// 验证未通过， 发生错误
		$message = '新增失败:' . $Teacher->getError();
		} else {
		// 提示操作成功， 并跳转至教师管理列表
		return $this->success('用户' . $Teacher->name . '新增成功。 ', url('index'));
		}
		// 获取到ThinkPHP的内置异常时， 直接向上抛出， 交给ThinkPHP处理
		} catch (\think\Exception\HttpResponseException $e) {
		throw $e;
		// 获取到正常的异常时， 输出异常
		} catch (\Exception $e) {
		return $e->getMessage();
		} return $this->error($message);
		}
	
}
