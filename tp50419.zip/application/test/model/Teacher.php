<?php 
namespace app\test\model;
use think\Model;

class Teacher extends Model
{
  static public function login($username,$password)
  {
  
  $map=array('username'=>$username);// get()方法需要一个字段数组，就是select 字段数组 from的作用。
  $Teacher=self::get($map);
	if(!is_null($Teacher) and $Teacher->checkPassword($password))
	{
		session('tid',$Teacher->getData('id'));
		return true;
	}else
	{return false;}  
  }
  
  public function checkPassword($password)
  {
	if($this->getData('password')===$password)  
	{return true;}
	else
	{return false;}
  }
}