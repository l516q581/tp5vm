<?php
namespace app\index\controller;
use think\Db;

class Index
{
    public function showteac()
    {
       $te=Db::name('teacher')->select();
	   dump($te);
    }
}
