<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"E:\P\htdocs\tp5\public/../application/test\view\loginc\index.html";i:1587293312;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>登录</title>
<link href="/static/bootstrap-3.3.7-dist/css/bootstrap.min.css" />
</head>

<body>
<form action="<?php echo url('login'); ?>" method="post">
<label for="username">username:</label><input type="text" name="username" id="username" />
<label for="password">password:</label><input type="password" name="password" id="password" />
<button type="submit">submit</button>
</form>
</body>
</html>
